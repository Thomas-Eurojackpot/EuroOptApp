import SwiftUI

struct StatisticsView: View {

    var body: some View {

        Text("Statistik")
            .font(.largeTitle)
            .frame(maxWidth: .infinity,
                   maxHeight: .infinity)

    }

}

#Preview {

    StatisticsView()

}
