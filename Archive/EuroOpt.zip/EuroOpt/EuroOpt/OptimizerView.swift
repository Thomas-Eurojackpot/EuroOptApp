import SwiftUI

struct OptimizerView: View {

    var body: some View {

        Text("Optimierer")
            .font(.largeTitle)
            .frame(maxWidth: .infinity,
                   maxHeight: .infinity)

    }

}

#Preview {

    OptimizerView()

}
